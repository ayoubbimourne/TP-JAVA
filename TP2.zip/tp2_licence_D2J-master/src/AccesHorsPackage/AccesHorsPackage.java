package AccesHorsPackage;

import accesInClass.Salle;

public class AccesHorsPackage extends Salle{

	public static void main(String[] args) {
		AccesHorsPackage ac=new AccesHorsPackage();
		// TODO Auto-generated method stub
		System.out.println(ac.id+"  "+ac.nom);
		
	}

}
