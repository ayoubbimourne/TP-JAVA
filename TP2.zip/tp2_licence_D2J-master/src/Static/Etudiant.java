package Static;

public class Etudiant {
public int id;
public String name;
static int nbEtudiants;
public Etudiant(int ide,String name,int nbEtudiants) {
	this.id=ide;
	this.name=name;
	this.nbEtudiants=nbEtudiants;
}

}
