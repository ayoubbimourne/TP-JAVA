package accesInClass;

public class acceeSamePackage  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Salle a=new Salle();
		System.out.println(a.id+" "+a.nom);
	}

}
