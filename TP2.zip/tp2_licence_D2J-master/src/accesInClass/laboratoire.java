package accesInClass;

public class laboratoire  extends Salle {
	
	String  type;

}
