package accesInClass;

public class salleCours extends Salle{
	int  nbrPlace;
	
	public salleCours(int n,int id,String nom) {
		
		super(id,nom);
		this.nbrPlace=n;
		
		
	}

}
