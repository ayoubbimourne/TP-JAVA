package accesInClass;

public class test {
	public int id;
	public String nom;
	
	public test(int id,String nom){
		this.id=id;
		this.nom=nom;
	}


}
