package accesInClass;

public class test2 {

	public static void main(String[] args) {
		test t=new test(1,"xx");
		test t1=new test(1,"xx");
		if(t.equals(t1)) 
			
	System.out.println("true");
		
		
		}
	
	
	
}
