package test.jpa.models;

public class Produit {
	
	
	private int id;
	private String name;
	private String price;

}
