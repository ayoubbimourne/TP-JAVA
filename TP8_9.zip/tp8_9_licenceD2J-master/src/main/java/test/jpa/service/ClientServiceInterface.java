package test.jpa.service;

import test.jpa.models.Client;

public interface ClientServiceInterface {
	
	
	public Client addClient(Client c);

}
