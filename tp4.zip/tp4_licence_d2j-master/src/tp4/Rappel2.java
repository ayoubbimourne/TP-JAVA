package tp4;

public class Rappel2 {
}
