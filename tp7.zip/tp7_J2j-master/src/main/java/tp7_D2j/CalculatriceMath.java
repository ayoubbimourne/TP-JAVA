package tp7_D2j;

public class CalculatriceMath extends Calculatrice {

}
